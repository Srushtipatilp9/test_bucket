__prog__ = "s3pypi"
__version__ = u"0.11.0"
