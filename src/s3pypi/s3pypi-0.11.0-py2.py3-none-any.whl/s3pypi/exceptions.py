class S3PyPiError(Exception):
    pass
